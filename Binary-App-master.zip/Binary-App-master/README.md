# Binary-App
For CS 321
